import argparse
import datetime
import time
import os
import yaml
import emon_mqtt



if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Read CSV file and publish to MQTT")
    parser.add_argument("-f", "--file", help="Path to CSV input file", required=True)
    parser.add_argument("-s", "--settingsPath", help="Path to emon_config.yml containing emon configuration", 
                        default="/share/emon_Suite/python/emon_config.yml")
    parser.add_argument("-l", "--logPath", help="Path to log directory", 
                        default="/share/Output/emonCSVToMQTT")
    parser.add_argument("-m", "--MQTT", help="IP address of MQTT server", default="localhost")
    args = parser.parse_args()
    
    mqttServer = str(args.MQTT)
    csvFile = str(args.file)
    logPath = str(args.logPath)
    
    # Create MQTT instance
    try:
        emonMQTT = emon_mqtt.emon_mqtt(mqtt_server=mqttServer, mqtt_port=1883, 
                                        settingsPath=args.settingsPath)
    except Exception as e:
        print(logPath, f"Error connecting to MQTT: {str(e)}")
        exit(1)
